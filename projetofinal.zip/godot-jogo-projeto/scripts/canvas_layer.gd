extends CanvasLayer

@onready var resume_btn = $VBoxContainer/RETORNAR
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	visible = false
	


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass

func _unhandled_input(event):
	if event.is_action_pressed("ui_cancel"):
		visible = true 
		get_tree().paused = true
		resume_btn.grab_focus()



func _on_retornar_pressed() -> void:
	get_tree().paused = false
	visible = false


func _on_sair_pressed() -> void:
	get_tree().quit()
