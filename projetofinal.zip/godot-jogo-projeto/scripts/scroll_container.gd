extends ScrollContainer

@export var text_node : Control
@export_range(1,10000,0.1) var credits_time : float = 1
@export_range(0,10000,0.1) var margin_increment : float = 0

# Nova variável para você escolher a cena da interface
@export_file("*.tscn") var menu_scene_path : String

@onready var margin : MarginContainer = $MarginContainer

func _ready() -> void:
	var tween = create_tween()
	
	await get_tree().create_timer(0.00).timeout
	
	var text_box_size = text_node.size.y
	
	var window_size = DisplayServer.window_get_size().y
	margin.add_theme_constant_override("margin_top", window_size + margin_increment)
	margin.add_theme_constant_override("margin_bottom", window_size + margin_increment)

	var scroll_amount : int = ceil(text_box_size * 3/2 + window_size * 2 + margin_increment)
	
	tween.tween_property(
		self,
		"scroll_vertical",
		scroll_amount,
		credits_time
	)
	tween.finished.connect(_acabou)
	tween.play()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_accept"):
		_ir_para_o_menu()

func _acabou() -> void:
	print("acabou!")
	_ir_para_o_menu()

func _ir_para_o_menu() -> void:
	if menu_scene_path != "":
		get_tree().change_scene_to_file(menu_scene_path)
	else:
		print("Erro: Falta arrastar a cena do Menu no Inspector!")
