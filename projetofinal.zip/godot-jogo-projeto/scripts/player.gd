extends CharacterBody2D

enum PlayerState {
	idle,
	walk,
	jump,
	fall,
	dead,
	hurt
}

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D
@onready var collision_shape: CollisionShape2D = $CollisionShape2D

@export var max_speed = 100.0
@export var acceleration = 200
@export var deceleration = 400
@export var slide_deceleration = 100

const JUMP_VELOCITY = -300.0

var jump_count = 0
@export var max_jump_count = 2
var direction = 0
var status: PlayerState

func _ready() -> void:
	go_to_idle_state()

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta

	match status:
		PlayerState.idle: idle_state(delta)
		PlayerState.walk: walk_state(delta)
		PlayerState.jump: jump_state(delta)
		PlayerState.fall: fall_state(delta)
		PlayerState.dead: dead_state(delta)
		PlayerState.hurt: hurt_state(delta)

	move_and_slide()


func go_to_idle_state():
	status = PlayerState.idle
	anim.play("idle")

func go_to_walk_state():
	status = PlayerState.walk
	anim.play("walk")

func go_to_jump_state():
	status = PlayerState.jump
	anim.play("jump")
	velocity.y = JUMP_VELOCITY
	jump_count += 1

func go_to_fall_state():
	status = PlayerState.fall
	anim.play("fall")


func go_to_hurt_state():
	if status == PlayerState.dead or status == PlayerState.hurt:
		return
	status = PlayerState.hurt
	anim.play("hurt")
	velocity = Vector2.ZERO
	await anim.animation_finished
	go_to_idle_state()

func go_to_dead_state():
	if status == PlayerState.dead:
		return
	status = PlayerState.dead
	anim.play("dead")
	velocity = Vector2.ZERO

	set_physics_process(false) 
	await anim.animation_finished
	get_tree().reload_current_scene()


func idle_state(delta):
	move(delta)
	if velocity.x != 0: go_to_walk_state()
	if Input.is_action_just_pressed("jump"): go_to_jump_state()

func walk_state(delta):
	move(delta)
	if velocity.x == 0: go_to_idle_state()
	if Input.is_action_just_pressed("jump"): go_to_jump_state()
	if !is_on_floor(): go_to_fall_state()

func jump_state(delta):
	move(delta)
	if Input.is_action_just_pressed("jump") and can_jump(): go_to_jump_state()
	if velocity.y > 0: go_to_fall_state()

func fall_state(delta):
	move(delta)
	if Input.is_action_just_pressed("jump") and can_jump(): go_to_jump_state()
	if is_on_floor():
		jump_count = 0
		go_to_idle_state() if velocity.x == 0 else go_to_walk_state()

func duck_state(_delta):
	update_direction()
	if Input.is_action_just_released("duck"):
		set_large_collider()
		go_to_idle_state()


func dead_state(_delta): pass
func hurt_state(_delta): pass


func move(delta):
	update_direction()
	if direction:
		velocity.x = move_toward(velocity.x, direction * max_speed, acceleration * delta)
	else:
		velocity.x = move_toward(velocity.x, 0, deceleration * delta)

func update_direction():
	direction = Input.get_axis("left", "right")
	if direction < 0: anim.flip_h = true
	elif direction > 0: anim.flip_h = false

func can_jump() -> bool:
	return jump_count < max_jump_count

func set_small_collider():
	if collision_shape and collision_shape.shape:
		collision_shape.shape.radius = 5
		collision_shape.shape.height = 10

func set_large_collider():
	if collision_shape and collision_shape.shape:
		collision_shape.shape.radius = 6
		collision_shape.shape.height = 16



func _on_hitbox_area_entered(area: Area2D) -> void:
	var body = area.get_parent()
	if velocity.y > 0 and body.has_method("take_damage"):
		body.take_damage()
		go_to_jump_state() 
	elif status != PlayerState.dead:
		go_to_dead_state()

func _on_front_collider_body_entered(body):
	if body.has_method("take_damage"):
		body.take_damage()
		
