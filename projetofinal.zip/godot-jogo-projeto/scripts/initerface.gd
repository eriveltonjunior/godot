extends Control


# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float):
	pass


func _on_start_pressed():
	get_tree().change_scene_to_file("res://scene/tropic.tscn")


func _on_start_3_pressed():
	get_tree().quit()


func _on_start_2_pressed():
	get_tree().change_scene_to_file("res://scene/scroll_container.tscn")
