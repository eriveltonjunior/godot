extends CharacterBody2D
const SPEED = 270.0
const JUMP_VELOCITY = -600.0
const VIDA = 1
const Dano = 0

@onready var ani: AnimatedSprite2D = $AnimatedSprite2D

var vida: int = VIDA
var posicao_inicial : Vector2

func _ready():
	posicao_inicial = global_position 

func voltar_ao_inicio():
	velocity = Vector2.ZERO

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	if is_on_floor():
		if direction > 0: 
			ani.flip_h = false
			ani.play("walk")
		elif direction < 0: 
			ani.flip_h = true 
			ani.play("walk")
		else: 
			ani.play("idle")
	else:
		ani.play("jump")
	move_and_slide()
