extends Area2D

@export var next_level = ""
@onready var collision_shape_2d: CollisionShape2D = $CollisionShape2D
@onready var vitoria: AudioStreamPlayer = $Vitoria

func _on_body_entered(_body: Node2D) -> void:
	call_deferred("load_next_scene")
func load_next_scene():
	get_tree().change_scene_to_file("res://scene/" + next_level + ".tscn")
