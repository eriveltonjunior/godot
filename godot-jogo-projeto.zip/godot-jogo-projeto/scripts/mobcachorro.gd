extends CharacterBody2D

enum Modlobo { walk, dead, hurt }

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D
@onready var hitbox: Area2D = $hitbox 
@onready var collision_shape: CollisionShape2D = $CollisionShape2D
@onready var ray_cast: RayCast2D = $RayCast2D 

var speed = -50.0
var status: Modlobo

func _ready() -> void:
	status = Modlobo.walk
	anim.play("walk")

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	match status:
		Modlobo.walk:
			if is_on_wall() or not ray_cast.is_colliding():
				flip_mob()
			
			velocity.x = speed
			
		Modlobo.dead, Modlobo.hurt:
			velocity.x = 0
			
	move_and_slide()

func flip_mob():
	speed = -speed 
	if speed > 0:
		anim.flip_h = false 
	else:
		anim.flip_h = true  
	
	ray_cast.position.x *= -1 

func take_damage():
	if status == Modlobo.dead:
		return
	go_to_dead_state()

func go_to_dead_state():
	status = Modlobo.dead
	anim.play("dead")
	
	if hitbox:
		hitbox.process_mode = Node.PROCESS_MODE_DISABLED
	
	collision_shape.set_deferred("disabled", true)
	
	await anim.animation_finished
	queue_free()
