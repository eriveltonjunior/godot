extends CharacterBody2D

enum mobcachorro {
	walk,
	dead
}

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

const SPEED = 300.0
const JUMP_VELOCITY = -400.0

var status: mobcachorro

func _ready() -> void:
	go_to_walk_state()

func _physics_process(delta: float) -> void:

	if not is_on_floor():
		velocity += get_gravity() * delta

	match status:
		mobcachorro.walk:
			walk_state(delta)
		mobcachorro.dead:
			dead_state(delta)



	move_and_slide()


func go_to_walk_state():
	status = mobcachorro.walk
	anim.play("walk")

func go_to_dead_state():
	status = mobcachorro.dead
	anim.play("dead")

func walk_state(_delta):
	pass

func dead_state(_delta):
	pass
	
func take_damage():
	go_to_dead_state()
